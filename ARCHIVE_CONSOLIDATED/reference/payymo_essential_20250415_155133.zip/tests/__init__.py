"""
Payymo Test Suite
This package contains tests for the Payymo application.
"""