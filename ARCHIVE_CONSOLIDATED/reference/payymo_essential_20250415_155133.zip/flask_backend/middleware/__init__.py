"""
Middleware Module

This package contains middleware components for the Flask application.
"""